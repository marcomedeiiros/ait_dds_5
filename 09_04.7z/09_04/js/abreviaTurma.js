'use strict';

export default function abreviaTurma(turma) {  
    return turma.toUpperCase(); 
}